import 'package:flutter/material.dart';

class books {
  String name;
  String book_path;
  String author_name;
  String file_path;
  String categoty;

  books(name, book_path, author_name, file_path, category) {
    this.name = name;
    this.book_path = book_path;
    this.author_name = author_name;
    this.file_path = file_path;
    this.categoty = category;
  }
}

class Best_seller {
  List<books> best_seller = [
    books('images/books/book3', 'Harry Potter and the Deathly Hallows',
        'J.K. Rowling', 'None', 'None'),
    books('images/books/book4', 'The fault in Our Stars', 'John Green', 'None',
        'None'),
    books(
        'images/books/book5', 'The Alchemist', 'Paulo Coelho', 'None', 'None'),
  ];

  String get_name(int book_id) {
    return best_seller[book_id].name;
  }

  String get_book_path(int book_id) {
    return best_seller[book_id].book_path;
  }

  String get_author_name(int book_id) {
    return best_seller[book_id].author_name;
  }

  String get_file_path(int book_id) {
    return best_seller[book_id].file_path;
  }

  String get_category(int book_id) {
    return best_seller[book_id].categoty;
  }
}
