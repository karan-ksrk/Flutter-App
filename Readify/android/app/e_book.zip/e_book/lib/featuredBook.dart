import 'package:flutter/material.dart';
import 'ForthPage.dart';

class FeaturedBooks extends StatelessWidget {
  FeaturedBooks({@required this.imagePath});

  final String imagePath;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => ForthPage()),
        );
      },
      child: Container(
        width: 188.0,
        height: 230.0,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20.0),
            image: DecorationImage(
              image: AssetImage(imagePath),
              fit: BoxFit.fill,
            )),
      ),
    );
  }
}
