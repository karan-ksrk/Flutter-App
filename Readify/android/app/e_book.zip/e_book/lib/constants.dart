import 'package:flutter/material.dart';

final kTextFieldStyle = TextStyle(
  color: Colors.white.withOpacity(0.32),
  fontFamily: 'Roboto',
);
