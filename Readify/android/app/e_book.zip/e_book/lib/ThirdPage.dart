import 'package:e_book/ForthPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'bottomNavigation.dart';
import 'bestSeller.dart';
import 'featuredBook.dart';
import 'topBar.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ThirdPage extends StatefulWidget {
  @override
  _ThirdPageState createState() => _ThirdPageState();
}

class _ThirdPageState extends State<ThirdPage> {
  final _auth = FirebaseAuth.instance;
  FirebaseUser loggedInuser;
  void getCurrentUser() async {
    try {
      final user = await _auth.currentUser();
      if (user != null) {
        loggedInuser = user;
        print(loggedInuser.email);
      }
    } catch (e) {
      print(e);
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getCurrentUser();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigation(),
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            TopBar(),
            Container(
              margin: EdgeInsets.only(left: 36.0, top: 34.53),
              child: Text(
                'Featured Books',
                style: TextStyle(fontSize: 19, letterSpacing: 0.6),
              ),
            ),
            Container(
              height: 250.0,
              margin: EdgeInsets.only(top: 23.53),
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: <Widget>[
                  SizedBox(width: 26.0),
                  FeaturedBooks(imagePath: 'images/books/book1.png'),
                  SizedBox(width: 26.0),
                  FeaturedBooks(imagePath: 'images/books/book2.png'),
                  SizedBox(width: 26.0),
                  FeaturedBooks(imagePath: 'images/books/book3.png'),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: 36.0, top: 34.53),
              child: Text(
                'Best Seller',
                style: TextStyle(fontSize: 19, letterSpacing: 0.6),
              ),
            ),
            Container(
              height: 239.0,
              child: Padding(
                padding: EdgeInsets.only(top: 23.53),
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: <Widget>[
                    SizedBox(width: 34.0),
                    BestSeller(
                      imagePath: 'images/books/book3.png',
                      bookTitle: 'Harry Potter and the Deathly Hallows',
                      authorName: 'J.K. Rowling',
                    ),
                    SizedBox(width: 19.67),
                    BestSeller(
                      imagePath: 'images/books/book4.png',
                      bookTitle: 'The fault In Our Stars',
                      authorName: 'John Green',
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class NavBarClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    // TODO: implement getClip
    return null;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}
