import 'package:e_book/topBar.dart';
import 'package:flutter/material.dart';
import 'bottomNavigation.dart';
import 'seventhPage.dart';

class FifthPage extends StatefulWidget {
  @override
  _FifthPageState createState() => _FifthPageState();
}

class _FifthPageState extends State<FifthPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigation(),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            TopBar(),
            Container(
              margin: EdgeInsets.only(left: 34.0, right: 36.0, top: 32.28),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Container(
                    height: 200.0,
                    width: 131.0,
                    decoration: BoxDecoration(
                        image: DecorationImage(
                      image: AssetImage('images/books/book3.png'),
                      fit: BoxFit.fill,
                    )),
                  ),
                  Container(
                    width: 144.0,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          'Harry Potter and the Deathly Hallows',
                          style: TextStyle(
                            fontSize: 14.0,
                          ),
                        ),
                        SizedBox(height: 8.0),
                        Text(
                          'J.K. Rowling',
                          style: TextStyle(
                            fontSize: 11.0,
                            color: Colors.black.withOpacity(0.4),
                          ),
                        ),
                        SizedBox(height: 17.0),
                        Text(
                          'Original Ebook',
                          style: TextStyle(
                            fontSize: 10.0,
                          ),
                        ),
                        Text(
                          '\$8.12',
                          style: TextStyle(
                            fontSize: 27.0,
                            fontWeight: FontWeight.w900,
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: 36.0, top: 63.0),
              child: Text(
                'Select payment Methods',
                style: TextStyle(fontSize: 17.0),
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: 40.0, top: 43.0),
              child: Row(
                children: <Widget>[
                  Icon(Icons.payment),
                  SizedBox(width: 17.5),
                  Text('Amazon Pay'),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: 40.0, top: 43.0),
              child: Row(
                children: <Widget>[
                  Icon(Icons.payment),
                  SizedBox(width: 17.5),
                  Text('Amazon Pay'),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: 40.0, top: 43.0),
              child: Row(
                children: <Widget>[
                  Icon(Icons.payment),
                  SizedBox(width: 17.5),
                  Text('Amazon Pay'),
                ],
              ),
            ),
            Center(
              child: Container(
                margin: EdgeInsets.only(top: 82, left: 37.1, right: 37.1),
                child: ButtonTheme(
                  minWidth: 302.0,
                  height: 38.0,
                  child: RaisedButton(
                    onPressed: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) => ShowPdf()));
                    },
                    color: Color(0xFF6D93FF),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(40.0),
                    ),
                    child: Text(
                      'Pay and Processed Ebook',
                      style: TextStyle(color: Colors.white, fontSize: 10.0),
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
