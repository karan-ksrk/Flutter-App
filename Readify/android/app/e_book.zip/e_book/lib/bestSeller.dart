import 'package:flutter/material.dart';

class BestSeller extends StatelessWidget {
  BestSeller(
      {@required this.imagePath,
      @required this.bookTitle,
      @required this.authorName});

  final String imagePath;
  final String bookTitle;
  final String authorName;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 126.33,
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(10.0)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          GestureDetector(
            child: Container(
              width: 126.0,
              height: 157.0,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15.0),
                  image: DecorationImage(
                    image: AssetImage(imagePath),
                    fit: BoxFit.fill,
                  )),
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 12.0, bottom: 9.0),
            child: Text(
              bookTitle,
              style: TextStyle(fontSize: 10),
            ),
          ),
          Text(
            authorName,
            style: TextStyle(
              fontSize: 10,
              color: Colors.black.withOpacity(0.4),
            ),
          )
        ],
      ),
    );
  }
}
