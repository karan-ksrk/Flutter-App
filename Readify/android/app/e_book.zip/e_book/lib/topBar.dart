import 'package:flutter/material.dart';

class TopBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 20.0, left: 36.0, right: 38.68),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        mainAxisSize: MainAxisSize.max,
        children: <Widget>[
          Icon(Icons.menu, color: Color(0xff707070)),
          Image.asset('images/search.png', width: 22.35, height: 22.35)
        ],
      ),
    );
  }
}
